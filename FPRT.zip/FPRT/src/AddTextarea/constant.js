export const MULTIPLE_CHOICE = "MultipleChoice";
export const CHECKBOXES = "Checkboxes";
export const DROPDOWN = "Dropdown";
export const TEXT = "Text";
export const PARAGRAPH = "Paragraph";
