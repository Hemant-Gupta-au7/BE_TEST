import './index.css';
import AddTextarea from './AddTextarea.js';

export default AddTextarea;